Ext.define('Device.controller.Connection', {
    extend: 'Ext.app.Controller',

    config: {
        refs: {
            connectionView: 'connection'
        }
    }
});
