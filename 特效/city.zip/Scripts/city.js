﻿var city = function (option) {
    this.init(option);
}
city.prototype = {
    data: [{ "name": "省市选择", "data": [{ "code": 0, "name": "北京市", "data": [{ "code": "0_0", "name": "东城区" }, { "code": "0_1", "name": "西城区" }, { "code": "0_2", "name": "崇文区" }, { "code": "0_3", "name": "宣武区" }, { "code": "0_4", "name": "朝阳区" }, { "code": "0_5", "name": "丰台区" }, { "code": "0_6", "name": "石景山区" }, { "code": "0_7", "name": "海淀区" }, { "code": "0_8", "name": "门头沟区" }, { "code": "0_9", "name": "房山区" }, { "code": "0_10", "name": "通州区" }, { "code": "0_11", "name": "顺义区" }, { "code": "0_12", "name": "昌平区" }, { "code": "0_13", "name": "大兴区" }, { "code": "0_14", "name": "怀柔区" }, { "code": "0_15", "name": "平谷区" }, { "code": "0_16", "name": "密云县" }, { "code": "0_17", "name": "延庆县" }, { "code": "0_18", "name": "延庆镇" }] }, { "code": 1, "name": "天津市", "data": [{ "code": "1_0", "name": "和平区" }, { "code": "1_1", "name": "河东区" }, { "code": "1_2", "name": "河西区" }, { "code": "1_3", "name": "南开区" }, { "code": "1_4", "name": "河北区" }, { "code": "1_5", "name": "红桥区" }, { "code": "1_6", "name": "塘沽区" }, { "code": "1_7", "name": "汉沽区" }, { "code": "1_8", "name": "大港区" }, { "code": "1_9", "name": "东丽区" }, { "code": "1_10", "name": "西青区" }, { "code": "1_11", "name": "津南区" }, { "code": "1_12", "name": "北辰区" }, { "code": "1_13", "name": "武清区" }, { "code": "1_14", "name": "宝坻区" }, { "code": "1_15", "name": "蓟县" }, { "code": "1_16", "name": "宁河县" }, { "code": "1_17", "name": "芦台镇" }, { "code": "1_18", "name": "静海县" }, { "code": "1_19", "name": "静海镇" }] }, { "code": 2, "name": "上海市", "data": [{ "code": "2_0", "name": "黄浦区" }, { "code": "2_1", "name": "卢湾区" }, { "code": "2_2", "name": "徐汇区" }, { "code": "2_3", "name": "长宁区" }, { "code": "2_4", "name": "静安区" }, { "code": "2_5", "name": "普陀区" }, { "code": "2_6", "name": "闸北区" }, { "code": "2_7", "name": "虹口区" }, { "code": "2_8", "name": "杨浦区" }, { "code": "2_9", "name": "闵行区" }, { "code": "2_10", "name": "宝山区" }, { "code": "2_11", "name": "嘉定区" }, { "code": "2_12", "name": "浦东新区" }, { "code": "2_13", "name": "金山区" }, { "code": "2_14", "name": "松江区" }, { "code": "2_15", "name": "青浦区" }, { "code": "2_16", "name": "南汇区" }, { "code": "2_17", "name": "奉贤区" }, { "code": "2_18", "name": "崇明县" }, { "code": "2_19", "name": "城桥镇" }] }, { "code": 3, "name": "重庆市", "data": [{ "code": "3_0", "name": "渝中区" }, { "code": "3_1", "name": "大渡口区" }, { "code": "3_2", "name": "江北区" }, { "code": "3_3", "name": "沙坪坝区" }, { "code": "3_4", "name": "九龙坡区" }, { "code": "3_5", "name": "南岸区" }, { "code": "3_6", "name": "北碚区" }, { "code": "3_7", "name": "万盛区" }, { "code": "3_8", "name": "双桥区" }, { "code": "3_9", "name": "渝北区" }, { "code": "3_10", "name": "巴南区" }, { "code": "3_11", "name": "万州区" }, { "code": "3_12", "name": "涪陵区" }, { "code": "3_13", "name": "黔江区" }, { "code": "3_14", "name": "长寿区" }, { "code": "3_15", "name": "合川市" }, { "code": "3_16", "name": "永川区市" }, { "code": "3_17", "name": "江津市" }, { "code": "3_18", "name": "南川市" }, { "code": "3_19", "name": "綦江县" }, { "code": "3_20", "name": "潼南县" }, { "code": "3_21", "name": "铜梁县" }, { "code": "3_22", "name": "大足县" }, { "code": "3_23", "name": "荣昌县" }, { "code": "3_24", "name": "璧山县" }, { "code": "3_25", "name": "垫江县" }, { "code": "3_26", "name": "武隆县" }, { "code": "3_27", "name": "丰都县" }, { "code": "3_28", "name": "城口县" }, { "code": "3_29", "name": "梁平县" }, { "code": "3_30", "name": "开县" }, { "code": "3_31", "name": "巫溪县" }, { "code": "3_32", "name": "巫山县" }, { "code": "3_33", "name": "奉节县" }, { "code": "3_34", "name": "云阳县" }, { "code": "3_35", "name": "忠县" }, { "code": "3_36", "name": "石柱土家族自治县" }, { "code": "3_37", "name": "彭水苗族土家族自治县" }, { "code": "3_38", "name": "酉阳土家族苗族自治县" }, { "code": "3_39", "name": "秀山土家族苗族自治县" }] }, { "code": 4, "name": "河北省", "data": [{ "code": "4_0", "name": "石家庄市" }, { "code": "4_1", "name": "张家口市" }, { "code": "4_2", "name": "承德市" }, { "code": "4_3", "name": "秦皇岛市" }, { "code": "4_4", "name": "唐山市" }, { "code": "4_5", "name": "廊坊市" }, { "code": "4_6", "name": "保定市" }, { "code": "4_7", "name": "衡水市" }, { "code": "4_8", "name": "沧州市" }, { "code": "4_9", "name": "邢台市" }, { "code": "4_10", "name": "邯郸市" }] }, { "code": 5, "name": "山西省", "data": [{ "code": "5_0", "name": "太原市" }, { "code": "5_1", "name": "朔州市" }, { "code": "5_2", "name": "大同市" }, { "code": "5_3", "name": "阳泉市" }, { "code": "5_4", "name": "长治市" }, { "code": "5_5", "name": "晋城市" }, { "code": "5_6", "name": "忻州市" }, { "code": "5_7", "name": "晋中市" }, { "code": "5_8", "name": "临汾市" }, { "code": "5_9", "name": "吕梁市" }, { "code": "5_10", "name": "运城市" }] }, { "code": 6, "name": "内蒙古", "data": [{ "code": "6_0", "name": "呼和浩特市" }, { "code": "6_1", "name": "包头市" }, { "code": "6_2", "name": "乌海市" }, { "code": "6_3", "name": "赤峰市" }, { "code": "6_4", "name": "通辽市" }, { "code": "6_5", "name": "呼伦贝尔市" }, { "code": "6_6", "name": "鄂尔多斯市" }, { "code": "6_7", "name": "乌兰察布市" }, { "code": "6_8", "name": "巴彦淖尔市" }, { "code": "6_9", "name": "兴安盟" }, { "code": "6_10", "name": "锡林郭勒盟" }, { "code": "6_11", "name": "阿拉善盟" }] }, { "code": 7, "name": "辽宁省", "data": [{ "code": "7_0", "name": "沈阳市" }, { "code": "7_1", "name": "朝阳市" }, { "code": "7_2", "name": "阜新市" }, { "code": "7_3", "name": "铁岭市" }, { "code": "7_4", "name": "抚顺市" }, { "code": "7_5", "name": "本溪市" }, { "code": "7_6", "name": "辽阳市" }, { "code": "7_7", "name": "鞍山市" }, { "code": "7_8", "name": "丹东市" }, { "code": "7_9", "name": "大连市" }, { "code": "7_10", "name": "营口市" }, { "code": "7_11", "name": "盘锦市" }, { "code": "7_12", "name": "锦州市" }, { "code": "7_13", "name": "葫芦岛市" }] }, { "code": 8, "name": "吉林省", "data": [{ "code": "8_0", "name": "长春市" }, { "code": "8_1", "name": "白城市" }, { "code": "8_2", "name": "松原市" }, { "code": "8_3", "name": "吉林市" }, { "code": "8_4", "name": "四平市" }, { "code": "8_5", "name": "辽源市" }, { "code": "8_6", "name": "通化市" }, { "code": "8_7", "name": "白山市" }, { "code": "8_8", "name": "延边州" }] }, { "code": 9, "name": "黑龙江省", "data": [{ "code": "9_0", "name": "哈尔滨市" }, { "code": "9_1", "name": "齐齐哈尔市" }, { "code": "9_2", "name": "七台河市" }, { "code": "9_3", "name": "黑河市" }, { "code": "9_4", "name": "大庆市" }, { "code": "9_5", "name": "鹤岗市" }, { "code": "9_6", "name": "伊春市" }, { "code": "9_7", "name": "佳木斯市" }, { "code": "9_8", "name": "双鸭山市" }, { "code": "9_9", "name": "鸡西市" }, { "code": "9_10", "name": "牡丹江市" }, { "code": "9_11", "name": "绥化市" }, { "code": "9_12", "name": "大兴安岭地区" }] }, { "code": 10, "name": "江苏省", "data": [{ "code": "10_0", "name": "南京市" }, { "code": "10_1", "name": "徐州市" }, { "code": "10_2", "name": "连云港市" }, { "code": "10_3", "name": "宿迁市" }, { "code": "10_4", "name": "淮安市" }, { "code": "10_5", "name": "盐城市" }, { "code": "10_6", "name": "扬州市" }, { "code": "10_7", "name": "泰州市" }, { "code": "10_8", "name": "南通市" }, { "code": "10_9", "name": "镇江市" }, { "code": "10_10", "name": "常州市" }, { "code": "10_11", "name": "无锡市" }, { "code": "10_12", "name": "苏州市" }] }, { "code": 11, "name": "浙江省", "data": [{ "code": "11_0", "name": "杭州市" }, { "code": "11_1", "name": "湖州市" }, { "code": "11_2", "name": "嘉兴市" }, { "code": "11_3", "name": "舟山市" }, { "code": "11_4", "name": "宁波市" }, { "code": "11_5", "name": "绍兴市" }, { "code": "11_6", "name": "衢州市" }, { "code": "11_7", "name": "金华市" }, { "code": "11_8", "name": "台州市" }, { "code": "11_9", "name": "温州市" }, { "code": "11_10", "name": "丽水市" }] }, { "code": 12, "name": "安徽省", "data": [{ "code": "12_0", "name": "合肥市" }, { "code": "12_1", "name": "宿州市" }, { "code": "12_2", "name": "淮北市" }, { "code": "12_3", "name": "亳州市" }, { "code": "12_4", "name": "阜阳市" }, { "code": "12_5", "name": "蚌埠市" }, { "code": "12_6", "name": "淮南市" }, { "code": "12_7", "name": "滁州市" }, { "code": "12_8", "name": "马鞍山市" }, { "code": "12_9", "name": "芜湖市" }, { "code": "12_10", "name": "铜陵市" }, { "code": "12_11", "name": "安庆市" }, { "code": "12_12", "name": "黄山市" }, { "code": "12_13", "name": "六安市" }, { "code": "12_14", "name": "巢湖市" }, { "code": "12_15", "name": "池州市" }, { "code": "12_16", "name": "宣城市" }] }, { "code": 13, "name": "福建省", "data": [{ "code": "13_0", "name": "福州市" }, { "code": "13_1", "name": "南平市" }, { "code": "13_2", "name": "莆田市" }, { "code": "13_3", "name": "三明市" }, { "code": "13_4", "name": "泉州市" }, { "code": "13_5", "name": "厦门市" }, { "code": "13_6", "name": "漳州市" }, { "code": "13_7", "name": "龙岩市" }, { "code": "13_8", "name": "宁德市" }] }, { "code": 14, "name": "江西省", "data": [{ "code": "14_0", "name": "南昌市" }, { "code": "14_1", "name": "九江市" }, { "code": "14_2", "name": "景德镇市" }, { "code": "14_3", "name": "鹰潭市" }, { "code": "14_4", "name": "新余市" }, { "code": "14_5", "name": "萍乡市" }, { "code": "14_6", "name": "赣州市" }, { "code": "14_7", "name": "上饶市" }, { "code": "14_8", "name": "抚州市" }, { "code": "14_9", "name": "宜春市" }, { "code": "14_10", "name": "吉安市" }] }, { "code": 15, "name": "山东省", "data": [{ "code": "15_0", "name": "济南市" }, { "code": "15_1", "name": "青岛市" }, { "code": "15_2", "name": "聊城市" }, { "code": "15_3", "name": "德州市" }, { "code": "15_4", "name": "东营市" }, { "code": "15_5", "name": "淄博市" }, { "code": "15_6", "name": "潍坊市" }, { "code": "15_7", "name": "烟台市" }, { "code": "15_8", "name": "威海市" }, { "code": "15_9", "name": "日照市" }, { "code": "15_10", "name": "临沂市" }, { "code": "15_11", "name": "枣庄市" }, { "code": "15_12", "name": "济宁市" }, { "code": "15_13", "name": "泰安市" }, { "code": "15_14", "name": "莱芜市" }, { "code": "15_15", "name": "滨州市" }, { "code": "15_16", "name": "菏泽市" }] }, { "code": 16, "name": "河南省", "data": [{ "code": "16_0", "name": "郑州市" }, { "code": "16_1", "name": "开封市" }, { "code": "16_2", "name": "三门峡市" }, { "code": "16_3", "name": "洛阳市" }, { "code": "16_4", "name": "焦作市" }, { "code": "16_5", "name": "新乡市" }, { "code": "16_6", "name": "鹤壁市" }, { "code": "16_7", "name": "安阳市" }, { "code": "16_8", "name": "濮阳市" }, { "code": "16_9", "name": "商丘市" }, { "code": "16_10", "name": "许昌市" }, { "code": "16_11", "name": "漯河市" }, { "code": "16_12", "name": "平顶山市" }, { "code": "16_13", "name": "南阳市" }, { "code": "16_14", "name": "信阳市" }, { "code": "16_15", "name": "周口市" }, { "code": "16_16", "name": "驻马店市" }] }, { "code": 17, "name": "湖北省", "data": [{ "code": "17_0", "name": "武汉市" }, { "code": "17_1", "name": "十堰市" }, { "code": "17_2", "name": "襄樊市" }, { "code": "17_3", "name": "荆门市" }, { "code": "17_4", "name": "孝感市" }, { "code": "17_5", "name": "黄冈市" }, { "code": "17_6", "name": "鄂州市" }, { "code": "17_7", "name": "黄石市" }, { "code": "17_8", "name": "咸宁市" }, { "code": "17_9", "name": "荆州市" }, { "code": "17_10", "name": "宜昌市" }, { "code": "17_11", "name": "随州市" }, { "code": "17_12", "name": "省直辖县级行政单位" }, { "code": "17_13", "name": "恩施州" }] }, { "code": 18, "name": "湖南省", "data": [{ "code": "18_0", "name": "长沙市" }, { "code": "18_1", "name": "张家界市" }, { "code": "18_2", "name": "常德市" }, { "code": "18_3", "name": "益阳市" }, { "code": "18_4", "name": "岳阳市" }, { "code": "18_5", "name": "株洲市" }, { "code": "18_6", "name": "湘潭市" }, { "code": "18_7", "name": "衡阳市" }, { "code": "18_8", "name": "郴州市" }, { "code": "18_9", "name": "永州市" }, { "code": "18_10", "name": "邵阳市" }, { "code": "18_11", "name": "怀化市" }, { "code": "18_12", "name": "娄底市" }, { "code": "18_13", "name": "湘西州" }] }, { "code": 19, "name": "广东省", "data": [{ "code": "19_0", "name": "广州市" }, { "code": "19_1", "name": "深圳市" }, { "code": "19_2", "name": "清远市" }, { "code": "19_3", "name": "韶关市" }, { "code": "19_4", "name": "河源市" }, { "code": "19_5", "name": "梅州市" }, { "code": "19_6", "name": "潮州市" }, { "code": "19_7", "name": "汕头市" }, { "code": "19_8", "name": "揭阳市" }, { "code": "19_9", "name": "汕尾市" }, { "code": "19_10", "name": "惠州市" }, { "code": "19_11", "name": "东莞市" }, { "code": "19_12", "name": "珠海市" }, { "code": "19_13", "name": "中山市" }, { "code": "19_14", "name": "江门市" }, { "code": "19_15", "name": "佛山市" }, { "code": "19_16", "name": "肇庆市" }, { "code": "19_17", "name": "云浮市" }, { "code": "19_18", "name": "阳江市" }, { "code": "19_19", "name": "茂名市" }, { "code": "19_20", "name": "湛江市" }] }, { "code": 20, "name": "广西", "data": [{ "code": "20_0", "name": "南宁市" }, { "code": "20_1", "name": "桂林市" }, { "code": "20_2", "name": "柳州市" }, { "code": "20_3", "name": "梧州市" }, { "code": "20_4", "name": "贵港市" }, { "code": "20_5", "name": "玉林市" }, { "code": "20_6", "name": "钦州市" }, { "code": "20_7", "name": "北海市" }, { "code": "20_8", "name": "防城港市" }, { "code": "20_9", "name": "崇左市" }, { "code": "20_10", "name": "百色市" }, { "code": "20_11", "name": "河池市" }, { "code": "20_12", "name": "来宾市" }, { "code": "20_13", "name": "贺州市" }] }, { "code": 21, "name": "海南省", "data": [{ "code": "21_0", "name": "海口市" }, { "code": "21_1", "name": "三亚市" }, { "code": "21_2", "name": "省直辖行政单位" }] }, { "code": 22, "name": "四川省", "data": [{ "code": "22_0", "name": "成都市" }, { "code": "22_1", "name": "广元市" }, { "code": "22_2", "name": "绵阳市" }, { "code": "22_3", "name": "德阳市" }, { "code": "22_4", "name": "南充市" }, { "code": "22_5", "name": "广安市" }, { "code": "22_6", "name": "遂宁市" }, { "code": "22_7", "name": "内江市" }, { "code": "22_8", "name": "乐山市" }, { "code": "22_9", "name": "自贡市" }, { "code": "22_10", "name": "泸州市" }, { "code": "22_11", "name": "宜宾市" }, { "code": "22_12", "name": "攀枝花市" }, { "code": "22_13", "name": "巴中市" }, { "code": "22_14", "name": "达州市" }, { "code": "22_15", "name": "资阳市" }, { "code": "22_16", "name": "眉山市" }, { "code": "22_17", "name": "雅安市" }, { "code": "22_18", "name": "阿坝州" }, { "code": "22_19", "name": "甘孜州" }, { "code": "22_20", "name": "凉山州" }] }, { "code": 23, "name": "贵州省", "data": [{ "code": "23_0", "name": "贵阳市" }, { "code": "23_1", "name": "六盘水市" }, { "code": "23_2", "name": "遵义市" }, { "code": "23_3", "name": "安顺市" }, { "code": "23_4", "name": "毕节地区" }, { "code": "23_5", "name": "铜仁地区" }, { "code": "23_6", "name": "黔东南州" }, { "code": "23_7", "name": "黔南州" }, { "code": "23_8", "name": "黔西南州" }] }, { "code": 24, "name": "云南省", "data": [{ "code": "24_0", "name": "昆明市" }, { "code": "24_1", "name": "曲靖市" }, { "code": "24_2", "name": "玉溪市" }, { "code": "24_3", "name": "保山市" }, { "code": "24_4", "name": "昭通市" }, { "code": "24_5", "name": "丽江市" }, { "code": "24_6", "name": "思茅市" }, { "code": "24_7", "name": "临沧市" }, { "code": "24_8", "name": "德宏州" }, { "code": "24_9", "name": "怒江州" }, { "code": "24_10", "name": "迪庆州" }, { "code": "24_11", "name": "大理州" }, { "code": "24_12", "name": "楚雄州" }, { "code": "24_13", "name": "红河州" }, { "code": "24_14", "name": "文山州" }, { "code": "24_15", "name": "西双版纳州" }] }, { "code": 25, "name": "西藏", "data": [{ "code": "25_0", "name": "拉萨市" }, { "code": "25_1", "name": "那曲地区" }, { "code": "25_2", "name": "昌都地区" }, { "code": "25_3", "name": "林芝地区" }, { "code": "25_4", "name": "山南地区" }, { "code": "25_5", "name": "日喀则地区" }, { "code": "25_6", "name": "阿里地区" }] }, { "code": 26, "name": "陕西省", "data": [{ "code": "26_0", "name": "西安市" }, { "code": "26_1", "name": "延安市" }, { "code": "26_2", "name": "铜川市" }, { "code": "26_3", "name": "渭南市" }, { "code": "26_4", "name": "咸阳市" }, { "code": "26_5", "name": "宝鸡市" }, { "code": "26_6", "name": "汉中市" }, { "code": "26_7", "name": "榆林市" }, { "code": "26_8", "name": "安康市" }, { "code": "26_9", "name": "商洛市" }] }, { "code": 27, "name": "甘肃省", "data": [{ "code": "27_0", "name": "兰州市" }, { "code": "27_1", "name": "嘉峪关市" }, { "code": "27_2", "name": "白银市" }, { "code": "27_3", "name": "天水市" }, { "code": "27_4", "name": "武威市" }, { "code": "27_5", "name": "酒泉市" }, { "code": "27_6", "name": "张掖市" }, { "code": "27_7", "name": "庆阳市" }, { "code": "27_8", "name": "平凉市" }, { "code": "27_9", "name": "定西市" }, { "code": "27_10", "name": "陇南市" }, { "code": "27_11", "name": "临夏州" }, { "code": "27_12", "name": "甘南州" }] }, { "code": 28, "name": "青海省", "data": [{ "code": "28_0", "name": "西宁市" }, { "code": "28_1", "name": "海东地区" }, { "code": "28_2", "name": "海北州" }, { "code": "28_3", "name": "海南州" }, { "code": "28_4", "name": "黄南州" }, { "code": "28_5", "name": "果洛州" }, { "code": "28_6", "name": "玉树州" }, { "code": "28_7", "name": "海西州" }] }, { "code": 29, "name": "宁夏", "data": [{ "code": "29_0", "name": "银川市" }, { "code": "29_1", "name": "石嘴山市" }, { "code": "29_2", "name": "吴忠市" }, { "code": "29_3", "name": "固原市" }, { "code": "29_4", "name": "中卫市" }] }, { "code": 30, "name": "新疆", "data": [{ "code": "30_0", "name": "乌鲁木齐市" }, { "code": "30_1", "name": "克拉玛依市" }, { "code": "30_2", "name": "自治区直辖县级行政单位" }, { "code": "30_3", "name": "喀什地区" }, { "code": "30_4", "name": "阿克苏地区" }, { "code": "30_5", "name": "和田地区" }, { "code": "30_6", "name": "吐鲁番地区" }, { "code": "30_7", "name": "哈密地区" }, { "code": "30_8", "name": "克孜勒苏柯州" }, { "code": "30_9", "name": "博尔塔拉州" }, { "code": "30_10", "name": "昌吉州" }, { "code": "30_11", "name": "巴音郭楞州" }, { "code": "30_12", "name": "伊犁州" }, { "code": "30_13", "name": "塔城地区" }, { "code": "30_14", "name": "阿勒泰地区" }] }, { "code": 31, "name": "香港", "data": [{ "code": "31_0", "name": "香港特别行政区" }] }, { "code": 32, "name": "澳门", "data": [{ "code": "32_0", "name": "澳门特别行政区" }] }, { "code": 33, "name": "台湾省", "data": [{ "code": "33_0", "name": "台北" }, { "code": "33_1", "name": "高雄" }, { "code": "33_2", "name": "台中" }, { "code": "33_3", "name": "花莲" }, { "code": "33_4", "name": "基隆" }, { "code": "33_5", "name": "嘉义" }, { "code": "33_6", "name": "金门" }, { "code": "33_7", "name": "连江" }, { "code": "33_8", "name": "苗栗" }, { "code": "33_9", "name": "南投" }, { "code": "33_10", "name": "澎湖" }, { "code": "33_11", "name": "屏东" }, { "code": "33_12", "name": "台东" }, { "code": "33_13", "name": "台南" }, { "code": "33_14", "name": "桃园" }, { "code": "33_15", "name": "新竹" }, { "code": "33_16", "name": "宜兰" }, { "code": "33_17", "name": "云林" }, { "code": "33_18", "name": "彰化" }] }] }],
    filter: {},
    container: Object,
    callback: {},
    appendHtml: "",

    // 功能描述：初始化
    init: function (option) {
        this.setOption(option);
        this.loadData();
        this.loadEvent();
        this.setFilter();
    },

    // 功能描述：选项设置
    setOption: function (option) {
        if (!option) return;

        this.container = $(option.container);
        this.filter = option.filter || {};
        this.callback = option.callback || null;
        this.appendHtml = option.appendHtml || "";
        if (this.container.length == 0) return;
    },

    // 功能描述：绑定菜单
    loadData: function () {
        var nav_data = this.data || [];
        if (nav_data.length == 0) return;

        var nav = [];
        var nav_menu = [], nav_tab_item = [], nav_tab_item_main = [], nav_tab_item_sub = [];
        var nav_menu_code;
        for (var i = 0; i < nav_data.length; i++) {
            nav_menu_code = nav_data[i]["code"] || "";
            nav_menu.push(this.extractData(nav_data[i], "<li code=\"##code##\"><span>##name##</span><i class=\"iconfont icon-unfold\"></i></li>"));

            nav_tab_data = nav_data[i]["data"] || [];
            if (nav_tab_data.length == 0) continue;

            nav_tab_item_sub = [];
            nav_tab_item_main = [];
            for (var j = 0; j < nav_tab_data.length; j++) {
                nav_tab_item_main.push(this.extractData(nav_tab_data[j], "<dd code=\"##code##\">##name##</dd>"));

                nav_tab_data_sub = nav_tab_data[j]["data"] || [];
                if (nav_tab_data_sub.length == 0) continue;

                nav_tab_item_sub.push("<dl class=\"filter-tab-item-sub\">");
                nav_tab_item_sub.push(this.extractData(nav_tab_data[j], "<dd code=\"##code##\">##name##</dd>"));
                for (var k = 0; k < nav_tab_data_sub.length; k++) {
                    nav_tab_item_sub.push(this.extractData(nav_tab_data_sub[k], "<dd code=\"##code##\">##name##</dd>"));
                }
                nav_tab_item_sub.push("</dl>");
            }

            if (nav_tab_item_sub.length > 0) {
                nav_tab_item.push("<li class=\"filter-tab-item filter-tab-item-mutil\" code=\"" + nav_menu_code + "\">");
                nav_tab_item.push("<dl class=\"filter-tab-item-main\">" + nav_tab_item_main.join("") + "</dl>");
                nav_tab_item.push(nav_tab_item_sub.join("") + "</li>");
            } else {
                nav_tab_item.push("<li class=\"filter-tab-item\" code=\"" + nav_menu_code + "\">");
                nav_tab_item.push("<dl class=\"filter-tab-item-sub\">" + nav_tab_item_main.join("") + "</dl></li>");
            }
        }

        nav.push("<div class=\"filter-close\">X</div>");
        nav.push("<ul class=\"filter-menu\">" + nav_menu.join("") + "</ul>");
        nav.push("<ul class=\"filter-tab\">" + nav_tab_item.join("") + this.appendHtml + "</ul>");

        this.container.html(nav.join(""));
    },

    // 功能描述：抽取数据
    extractData: function (data, template) {
        if (!data || !template) return "";

        var code = data["code"] || "";
        var name = data["name"] || "";

        return template.replace("##code##", code).replace("##name##", name);
    },

    // 功能描述：加载事件
    loadEvent: function () {
        var me = this;

        this.container.find(".filter-menu li").click(function () {
            $(".filter-tab .filter-tab-item").hide();
            me.container.find(".filter-tab .filter-tab-item-append").show();
            var obj = me.container.find(".filter-tab .filter-tab-item").eq($(this).index());
            if (obj) {
                if (obj.hasClass("filter-tab-item-mutil") && obj.find(".filter-tab-item-main dd.on").length == 0) {
                    obj.find(".filter-tab-item-main dd:first-child").click();
                } else if (obj.find(".filter-tab-item-sub dd.on").length == 0) {
                    obj.find(".filter-tab-item-sub dd:first-child").addClass("on");
                }
                obj.show();
            }

            return false;
        });

        this.container.find(".filter-tab-item-main dd").click(function () {
            $(this).siblings().removeClass("on");
            $(this).addClass("on");
            $(this).parent().parent().find(".filter-tab-item-sub").hide();
            var obj = $(this).parent().parent().find(".filter-tab-item-sub").eq($(this).index());
            if (obj) {
                if (obj.find("dd.on").length == 0) {
                    obj.find("dd:first-child").addClass("on");
                }
                obj.show();
            }

            return false;
        });

        this.container.find(".filter-tab .filter-tab-item-sub dd").click(function () {
            $(this).parent().parent().find("dd.selected").removeClass("selected");
            $(this).addClass("selected");
            $(".filter-tab-item").hide();
            var result = me.getFilter();

            var fcode = $(this).attr("code") || "";
            var fname = $(this).html() || "";
            var idx = $(this).parent().parent().index();
            var obj = me.container.find(".filter-menu li").eq(idx);
            if (obj) {
                //obj.find("span").html(fname);
                obj.find("span").attr("code", fcode);
            }

            //回调函数
            if ($.isFunction(me.callback)) {
                me.callback(result);
            }

            return false;
        });

        this.container.find(".filter-close").click(function () {
            $(".txt-city-list").hide(300);
        })
    },

    // 功能描述：设置过滤条件
    setFilter: function () {
        for (var i = 0; i < this.data.length; i++) {
            var code = this.data[i].code || "";
            if (code == "") continue;
            if (!this.data[i].data || isNaN(this.data[i].data.length) || this.data[i].data.length <= 0) continue;

            var item = this.data[i].data[0];
            if (!this.filter[code]) continue;
        }

        for (var key in this.filter) {
            var fobj = this.filter[key] || null;
            if (!fobj) continue;

            var fcode = fobj["code"] || "";
            var fname = fobj["name"] || "";
            if (fcode == "" || fname == "") {

            }

            var obj = $(".filter-menu li[code=" + key + "]");
            if (obj) {
                obj.attr("fcode", fcode);
                obj.find("span").html(fname);
            }

            obj = $(".filter-tab .filter-tab-item[code=" + key + "]");
            if (obj) {
                obj.find(".filter-tab-item-sub dd").each(function () {
                    var code = $(this).attr("code") || "";
                    if (code == fcode) {
                        $(this).addClass("selected");
                        return false;
                    }
                })
            }
        }
    },

    // 功能描述：获取过滤条件
    getFilter: function () {
        var result = [], strResult = [];
        this.container.find(".filter-tab .filter-tab-item-main dd.on").each(function () {
            var code = $(this).attr("code") || "";
            var name = $(this).html() || "";
            result.push({ type: "province", code: code, name: name });
        });
        this.container.find(".filter-tab .filter-tab-item-sub dd.selected").each(function () {
            var code = $(this).attr("code") || "";
            var name = $(this).html() || "";
            result.push({ type: "city", code: code, name: name });
        });
        return result;
    }
}