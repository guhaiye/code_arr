$(function(){
	var mycity = new city({ container: ".city-container", callback: function (result) {
			if (result && result.length >0) {
				var strCity, strProvince;
				for (var i = 0; i < result.length; i++) {
					switch (result[i].type) {
						case "city":
							strCity = result[i].name;
							break;
						case "province":
							strProvince = result[i].name;
							break;
					}
				}
				$(".btn-city").html("已选择：" + strProvince + " - " + strCity);
			}
			$(".txt-city-list").hide(300);
		}
	});
	
	$(".btn-city").click(function(){
		mycity.container.find(".filter-menu li:nth-child(1)").click();
		$(".txt-city-list").show(300);
	});	
});
