# cityPicker
适用于移动端的地址选择器

##下载
        npm install citypicker  或
        
        bower install cityPicker git://github.com/lwzhang/cityPicker.git

##使用方法
        <input type="text" class="city"/>
        
        $(".city").CityPicker();
